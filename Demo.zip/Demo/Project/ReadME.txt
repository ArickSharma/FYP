This project is about face recognition. Inside Project folder there 2 folders 
and 3 python program and one YML file

Folders:
------------
- cascade: this folder contain HAARcascade file to train model
- Images: this folder contain input images to train


python Files:
--------------
cameraStarter.py : to check camera is working properly
faceRecognizer.py: program to recognize faces
face-train.py : to train new input images

YML:
------------
trainner.yml: detail of trained images

--------------------------------------------------------------------------------
|  NOTE**								       |
|   Before run this file make sure your system already have openCV, numpy      |
|   and pickle installed.						       |
|									       |
--------------------------------------------------------------------------------

- To run this project open faceRecognizer.py with python pycharm
- run 'faceRecognizer' or press shift+f10 
- it will open your web camera of your pc and start detect face automatically 
- to Quit capture window simply press 'Q' and it will exit.

I have already train your faces as "Laxmi-Hari-Nepal" photos are collected from 
your facebook page. I have try by showing train images with mobile phone and it 
successfully detect and recognize. i hope it will detect your face accurately in 
real time. all the result depend on size of the train model[probably too low], 
time gap between train image capture date and current date[that is unknown] and 
your current look, beard, glasses can effect the result. my test result is inside 
project folder as "TestImage1" & "TestImage2". 



				"Thank You"
